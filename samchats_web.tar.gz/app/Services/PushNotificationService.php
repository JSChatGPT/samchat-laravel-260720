<?php

namespace App\Services;

use App\Models\User;
use Illuminate\Support\Facades\Log;
use Kreait\Firebase\Messaging\CloudMessage;
use Kreait\Firebase\Messaging\Notification;
use Kreait\Laravel\Firebase\Facades\Firebase;
use Throwable;

class PushNotificationService
{
    /**
     * Send a push notification to every device registered for a user.
     * No-ops (with a logged warning) if Firebase isn't configured, so the
     * app keeps working normally in environments without push set up.
     *
     * @param  array<string, mixed>  $data  string-keyed, string-valued payload merged into the FCM data payload
     */
    public function sendToUser(User $user, string $title, string $body, array $data = []): void
    {
        $tokens = $user->deviceTokens->pluck('token')->all();

        if (empty($tokens)) {
            return;
        }

        if (empty(config('firebase.projects.app.credentials'))) {
            Log::warning('Push notification skipped: FIREBASE_CREDENTIALS is not configured.');
            return;
        }

        $message = CloudMessage::new()
            ->withNotification(Notification::create($title, $body))
            ->withData(array_map('strval', $data));

        try {
            $report = Firebase::messaging()->sendMulticast($message, $tokens);
        } catch (Throwable $e) {
            Log::error('Push notification send failed', ['error' => $e->getMessage(), 'user_id' => $user->id]);
            return;
        }

        foreach ($report->failures()->getItems() as $failure) {
            if ($failure->messageTargetWasInvalid() || $failure->messageWasSentToUnknownToken()) {
                $user->deviceTokens()->where('token', $failure->target()->value())->delete();
            }
        }
    }
}
